package com.flash.app;

import com.flash.app.dao.RequestPaymentDAO;
import com.flash.app.enitity.RequestPayment;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

public class RequstPaymentDAOTests {

    @Test
    void contextLoads() {

        RequestPaymentDAO requestPaymentDAO = new RequestPaymentDAO() {
            @Override
            public RequestPayment findById(Integer id) {
                return null;
            }

            @Override
            public List<RequestPayment> findByFromUserId(Integer FromUserId) {
                return null;
            }

            @Override
            public List<RequestPayment> findByToUserId(Integer ToUserId) {
                return null;
            }

            @Override
            public List<RequestPayment> findByRequestCode(Integer RequestCode) {
                return null;
            }

            @Override
            public List<RequestPayment> findAll() {
                return null;
            }

            @Override
            public List<RequestPayment> findAll(Sort sort) {
                return null;
            }

            @Override
            public List<RequestPayment> findAllById(Iterable<Long> longs) {
                return null;
            }

            @Override
            public <S extends RequestPayment> List<S> saveAll(Iterable<S> entities) {
                return null;
            }

            @Override
            public void flush() {

            }

            @Override
            public <S extends RequestPayment> S saveAndFlush(S entity) {
                return null;
            }

            @Override
            public <S extends RequestPayment> List<S> saveAllAndFlush(Iterable<S> entities) {
                return null;
            }

            @Override
            public void deleteAllInBatch(Iterable<RequestPayment> entities) {

            }

            @Override
            public void deleteAllByIdInBatch(Iterable<Long> longs) {

            }

            @Override
            public void deleteAllInBatch() {

            }

            @Override
            public RequestPayment getOne(Long aLong) {
                return null;
            }

            @Override
            public RequestPayment getById(Long aLong) {
                return null;
            }

            @Override
            public <S extends RequestPayment> List<S> findAll(Example<S> example) {
                return null;
            }

            @Override
            public <S extends RequestPayment> List<S> findAll(Example<S> example, Sort sort) {
                return null;
            }

            @Override
            public Page<RequestPayment> findAll(Pageable pageable) {
                return null;
            }

            @Override
            public <S extends RequestPayment> S save(S entity) {
                return null;
            }

            @Override
            public Optional<RequestPayment> findById(Long aLong) {
                return Optional.empty();
            }

            @Override
            public boolean existsById(Long aLong) {
                return false;
            }

            @Override
            public long count() {
                return 0;
            }

            @Override
            public void deleteById(Long aLong) {

            }

            @Override
            public void delete(RequestPayment entity) {

            }

            @Override
            public void deleteAllById(Iterable<? extends Long> longs) {

            }

            @Override
            public void deleteAll(Iterable<? extends RequestPayment> entities) {

            }

            @Override
            public void deleteAll() {

            }

            @Override
            public <S extends RequestPayment> Optional<S> findOne(Example<S> example) {
                return Optional.empty();
            }

            @Override
            public <S extends RequestPayment> Page<S> findAll(Example<S> example, Pageable pageable) {
                return null;
            }

            @Override
            public <S extends RequestPayment> long count(Example<S> example) {
                return 0;
            }

            @Override
            public <S extends RequestPayment> boolean exists(Example<S> example) {
                return false;
            }
        };

    }
}
