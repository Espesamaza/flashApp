package com.flash.app;

import org.junit.jupiter.api.Test;

public class FlashApplicationTests {

    @Test
    void contextLoads() {
    }
}
