
# Money transfer application using Spring.

FlashApp is a web application for user to exchange Money. The user is able register, 
after the account is created, the user is directed to the secure login. 
After the registered user is losged in, they can start to transfer money amongst themselves.
The challenge i faced was to link front end to back end.



